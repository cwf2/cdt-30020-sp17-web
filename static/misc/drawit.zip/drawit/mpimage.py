''' mpimage.py: Convert DrawIt images to Matplotlib '''

import matplotlib.pyplot
import matplotlib.image
import requests
import numpy

from drawit.point import Point
from drawit.color import Color
from drawit.image import Image

class MPImage(object):
    ''' Tools for interacting with matplotlib '''
    
    @staticmethod
    def read_png(path):
        ''' Read image from path '''
        
        mp_data = matplotlib.image.imread(path)
        height = len(mp_data)
        width = len(mp_data[0])
        
        image = Image(width, height)
        
        for x in range(width):
            for y in range(height):
                r = int(mp_data[y][x][0] * 255)
                g = int(mp_data[y][x][1] * 255)
                b = int(mp_data[y][x][2] * 255)

                image[Point(x,y)] = Color(r, g, b)
        
        return image
        
    
    @staticmethod
    def to_mp_data(image):
        ''' Convert DrawIt format to matplotlib.image '''

        mp_data = numpy.zeros((image.height, image.width, 3), "uint8")
        for x in range(image.width):
            for y in range(image.height):
                color = image[Point(x,y)]
                mp_data[y][x] = [color.r, color.g, color.b]
    
        return mp_data
    
    @staticmethod
    def write_png(image, path):
        ''' Write DrawIt image to path in PNG format '''

        matplotlib.image.imsave(path, MPImage.to_mp_data(image))
    
    
    @staticmethod
    def show(image):
        ''' Display DrawIt image inline in Jupyter '''    
        matplotlib.pyplot.imshow(MPImage.to_mp_data(image), 
            resample="none", interpolation="none")
    
    