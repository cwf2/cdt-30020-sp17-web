''' image.py: DrawIt Image '''

from color import Color
from point import Point

import math

class Image(object):
    DEFAULT_WIDTH  = 640
    DEFAULT_HEIGHT = 480

    def __init__(self, width=DEFAULT_WIDTH, height=DEFAULT_HEIGHT):
        ''' Initialize Image object's instance variables '''
        self.pixels = []
        self.height = height
        self.width = width
        
        self.clear()
    

    def __eq__(self, other):
        ''' Returns True if current instance and other object are equal '''
        
        if self.height != other.height or self.width != other.width:
            return False
        
        for y in range(self.height):
            for x in range(self.width):
                p = Point(x,y)
                if self[p] != other[p]:
                    return False

        return True
        

    def __ne__(self, other):
        ''' Returns True if current instane and other object are not equal '''
        return not self.__eq__(other)
        
        

    def __repr__(self):
        ''' Returns string representing Image object '''
        return("Image(width={w},height={h})".format(
            w=self.width, h=self.height))


    def __getitem__(self, point):
        ''' Returns pixel specified by point

        If point is not with the bounds of the Image, then an IndexError is raised.
        '''
        self.check_bounds(point)
        
        row = point.y
        col = point.x
        
        return self.pixels[row][col]


    def __setitem__(self, point, color):
        ''' Sets pixel specified by point to given color

        If point is not with the bounds of the Image, then an IndexError is raised.
        '''
        self.check_bounds(point)
        
        row = point.y
        col = point.x
        
        self.pixels[row][col] = color
        

    def clear(self):
        ''' Clears Image by setting all pixels to default Color '''
        self.pixels = []
        for row in range(self.height):
            row = []
            for col in range(self.width):
                row.append(Color())
            self.pixels.append(row)
    

    def check_bounds(self, point):
        ''' Check that point is within bounds of image '''
        row = point.y
        col = point.x
        if row < 0 or row >= self.height or col < 0 or col >= self.width:
            raise IndexError("Point out of image bounds")
        

    def draw_line(self, point0, point1, color):
        ''' Draw a line from point0 to point1 '''
        
        self[point0] = color
        self[point1] = color
        
        dist = int(round(point0.distance_from(point1)))
        dy = point1.y - point0.y
        dx = point1.x - point0.x
        theta = math.atan2(dy, dx)
        
        for i in range(dist):
            x = point0.x + i * math.cos(theta)
            y = point0.y + i * math.sin(theta)
            self[Point(x,y)] = color


    def draw_rectangle(self, point0, point1, color):
        ''' Draw a rectangle from point0 to point1 '''
        
        x0, x1 = sorted([point0.x, point1.x])
        y0, y1 = sorted([point0.y, point1.y])
        
        for x in range(x0, x1+1):
            for y in range(y0, y1+1):
                self[Point(x,y)] = color
        

    def draw_circle(self, center, radius, color):
        ''' Draw a circle with center point and radius '''
        
        x0 = center.x - radius
        x1 = center.x + radius
        y0 = center.y - radius
        y1 = center.y + radius
        
        for x in range(x0, x1+1):
            for y in range(y0, y1+1):
                p = Point(x,y)
                if center.distance_from(p) <= radius:
                    self[p] = color
                    
   
    def gradient(self, center, color0, color1):
        ''' Fill image with a gradient
        
        Fade from color1 to color2 with distance from center
        '''
        
        maxdist = max([
            center.distance_from(Point(0,0)),
            center.distance_from(Point(0,self.height)),
            center.distance_from(Point(self.width, 0)),
            center.distance_from(Point(self.width, self.height))
        ])
        
        for x in range(self.width):
            for y in range(self.height):
                
                p = Point(x,y)
                factor = center.distance_from(p) / maxdist
                
                r = int(round((color1.r - color0.r) * factor)) + color0.r
                g = int(round((color1.g - color0.g) * factor)) + color0.g
                b = int(round((color1.b - color0.b) * factor)) + color0.b                

                self[p] = Color(r,g,b)

# vim: set sts=4 sw=4 ts=8 expandtab ft=python:
