#!/usr/bin/env python
'''A minimal server for Test 3'''

# import statements
import tornado.ioloop
import tornado.web
import os

PORT = 8888

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.render('test3.html')


class SearchHandler(tornado.web.RequestHandler):
    def get(self):

        doc_id = self.get_argument("doc_id")
        file = os.path.join("data", "state_of_the_union", doc_id + ".txt")
        
        count = {}
        
        with open(file) as fh:
            words = " ".join(fh.readlines()).lower().split()
            for word in words:
                count[word] = count.get(word, 0) + 1
        
        top_terms = sorted(count.keys(), key=count.get, reverse=True)[:20]
        sorted_list = []
        for word in top_terms:
            sorted_list.append({"word":word, "count":count[word]})
        
        self.write(dict(data=sorted_list))
        

# main code block
if __name__ == '__main__':    
    # create app, register handlers
    app = tornado.web.Application([
            (r'/', MainHandler),
            (r'/search', SearchHandler),
            (r'/css/(.*)', tornado.web.StaticFileHandler, {'path':'css'}),
            (r'/js/(.*)', tornado.web.StaticFileHandler, {'path':'js'}),
        ],
        template_path = 'html',
        debug = True,
    )

    # run the app
    app.listen(PORT)
    tornado.ioloop.IOLoop.current().start()
    
