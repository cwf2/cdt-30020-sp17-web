#!/usr/bin/env python
'''Interact with a database of dog breeds'''

# import statements
import tornado.ioloop
import tornado.web
import requests

PORT = 8888

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.render('static/test_3_practice.html')


class SearchHandler(tornado.web.RequestHandler):
    def get(self):
        url = "http://ur.nd.edu/request/eds.php"
        uid = self.get_argument("uid")
        res = requests.get(url, params={"uid":uid})
        if res.ok:
            self.write(res.json())


# main code block
if __name__ == '__main__':    
    # create app, register handlers
    app = tornado.web.Application([
            (r'/', MainHandler),
            (r'/search', SearchHandler),
            (r'/(.*\.css)', tornado.web.StaticFileHandler, {'path':'static'}),
            (r'/(.*\.js)', tornado.web.StaticFileHandler, {'path':'static'}),
        ],
        debug = True
    )

    # run the app
    app.listen(PORT)
    tornado.ioloop.IOLoop.current().start()
    
