#!/usr/bin/env python
import sqlite3
import os

class EventsDB(object):
    '''A connection to the Events database'''
    
    def __init__(self):
        # file names are hard-coded
        self.db_file = 'events.db'
        self.data_file = 'events.tsv'
        
        # connect to database
        self.conn = sqlite3.connect(self.db_file)
        self.conn.row_factory = sqlite3.Row
        
        # delete existing database file
        if os.path.exists(self.db_file):
            os.unlink(self.db_file)
        
        # create tables, add data
        self._create_table()
        self._populate_table()
    
    
    def _create_table(self):
        '''Create the table'''
        # TODO
    
    
    def _populate_table(self):
        '''Fill the table with data from tsv file'''
        # TODO
    
    
    def search_location(self, location):
        '''Return events that match location'''
        # TODO
    
    
# main block 
#  - don't mess with this code
#  - you can run this file as a script for debugging
if __name__ == '__main__':
    db = EventsDB()
    rows = db.search_location('Joyce Center')
    for row in rows:
        print 'Event id: {}'.format(row['event_id'])
        print 'Event:    {}'.format(row['event'])
        print 'Location: {}'.format(row['location'])
        print 'Date:     {}'.format(row['date'])
        print
