#!/usr/bin/env python
import sqlite3
import os

class BattlesDB(object):
    '''A connection to the Civil War battles database'''
    
    def __init__(self):
        # file names are hard-coded
        self.db_file = 'battles.db'
        self.data_file = 'battles.tsv'
        
        # delete existing database file
        if os.path.exists(self.db_file):
            os.unlink(self.db_file)

        # connect to database
        self.conn = sqlite3.connect(self.db_file)
        self.conn.row_factory = sqlite3.Row        
        
        # create tables, add data
        self._create_table()
        self._populate_table()
    
    
    def _create_table(self):
        '''Create the table'''
        # TODO
        pass
    
    
    def _populate_table(self):
        '''Fill the table with data from tsv file'''
        # TODO
        pass
    
    
    def search_state(self, state):
        '''Return events that match state'''
        # TODO
        pass
    
    
# main block 
#  - don't mess with this code
#  - you can run this file as a script for debugging
if __name__ == '__main__':
    db = BattlesDB()
    rows = db.search_state('MO')
    if rows is not None:
        for row in rows:
            for k in row.keys():
                print '{:10s}\t{}'.format(k + ':', row[k])
            print
