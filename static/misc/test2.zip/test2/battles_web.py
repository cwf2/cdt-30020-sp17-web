#!/usr/bin/env python
'''Civil War battles search app'''

from battles_db import BattlesDB

import logging
import tornado.ioloop
import tornado.web

# Global values
PORT = 8888

# Handlers
class MainHandler(tornado.web.RequestHandler):
    '''Render the landing page'''

    def get(self):
        self.render('search.html')


class SearchHandler(tornado.web.RequestHandler):
    '''Handles search requests'''
    
    def initialize(self, db):
        # set instance variable
        self.db = db
        
    def get(self):
        # TODO
        pass


# main code block
if __name__ == '__main__':
    # TODO: create the database connection
    
    app = tornado.web.Application([
            (r'/', MainHandler),
            # TODO: register handler here
        ],
        debug = True
    )

    # run the app
    app.listen(PORT)
    tornado.ioloop.IOLoop.current().start()
