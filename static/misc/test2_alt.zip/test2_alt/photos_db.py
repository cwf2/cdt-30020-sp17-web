#!/usr/bin/env python
'''Working with Civil War photos'''
import sqlite3
import os

class PhotosDB(object):
    '''A connection to the Civil War photos database'''
    
    def __init__(self):
        # file names are hard-coded
        self.db_file = 'cw_photos.db'
        self.data_file = 'cw_photos.tsv'
        
        # delete existing database file
        if os.path.exists(self.db_file):
            os.unlink(self.db_file)

        # connect to database
        self.conn = sqlite3.connect(self.db_file)
        self.conn.row_factory = sqlite3.Row        
        
        # create tables, add data
        self._create_table()
        self._populate_table()
    
    
    def _create_table(self):
        '''Create the table'''
        # TODO
        pass
    
    
    def _populate_table(self):
        '''Fill the table with data from tsv file'''
        # TODO
        pass
    
    
    def search_year(self, year):
        '''Return photos that match year'''
        # TODO
        pass
    
    
# main block 
#  - don't mess with this code
#  - you can run this file as a script for debugging
if __name__ == '__main__':
    db = PhotosDB()
    rows = db.search_year('1865')
    if rows is not None:
        for row in rows:
            for k in row.keys():
                print '{:10s}\t{}'.format(k + ':', row[k])
            print
