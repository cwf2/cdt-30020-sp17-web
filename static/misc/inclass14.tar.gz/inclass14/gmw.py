import os
import tornado.ioloop
import tornado.web

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.render('assets/templates/index.html')

class CharHandler(tornado.web.RequestHandler):
    def get(self):
        
        error_message = None
        
        try:
            user_name = self.get_query_argument('user_name')
        except tornado.web.MissingArgumentError:
            user_name = ''

        try:
            char_name = self.get_query_argument('fav_char')
        except tornado.web.MissingArgumentError:
            char_name = ''
        
        if user_name == '':
            self.render('assets/templates/bad_input.html',
            message = "You didn't enter your name!")
        elif char_name == '':
            self.render('assets/templates/bad_input.html',
            message = "You didn't pick a character!")
        elif char_name not in ['riley', 'maya', 'lucas', 'farkle']:
            self.render('assets/templates/bad_input.html',
            message="You have to pick one of the suggested characters.")
        else:
            self.render('assets/templates/fav_char.html',
                user_name = user_name, char_name = char_name.title())


if __name__ == "__main__":
    app = tornado.web.Application([
        (r'/', MainHandler),
        (r'/character', CharHandler),
        (r'/css/(.*)', tornado.web.StaticFileHandler, {'path':'assets/css'}),
        (r'/img/(.*)', tornado.web.StaticFileHandler, {'path':'assets/images'}),
    ], debug = True)
    app.listen(os.environ['PORT'])
    tornado.ioloop.IOLoop.current().start()
