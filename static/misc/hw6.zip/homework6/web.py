#!/usr/bin/env python
'''Interact with a catalogue of children's fiction'''

# import statements
import os
import sqlite3
import tornado.ioloop
import tornado.web

from kidslit import LibraryDB


# global values
DB_FILE = 'kidslit.db'
AUTH_FILE = os.path.join('json', 'authors.json')
BOOK_FILE = os.path.join('json', 'books.json')


# Class definitions
#  - HTTP Request Handlers:
class AuthorSearchHandler(tornado.web.RequestHandler):
    '''Author records matching a name'''
    
    def initialize(self, db):
        self.db = db

    def get(self, name=''):
        '''Search db and render author results page'''
        
        rows = self.db.search_authors_name('%{}%'.format(name))
        
        self.render('author_index.html', rows=rows)

class AuthorDetailHandler(tornado.web.RequestHandler):
    '''Detail for a single author'''
    
    def initialize(self, db):
        self.db = db
    
    def get(self, auth_id):
        '''Search db and render author detail page'''
        
        author = self.db.author_detail(auth_id)
        books = self.db.search_books_author(auth_id)
        
        if books:
            self.render('author_detail.html', 
                author = author,
                books = books)
        else:
            raise tornado.web.HTTPError(404)


# main code block
if __name__ == '__main__':
    db = LibraryDB(DB_FILE, AUTH_FILE, BOOK_FILE)
    
    # create app, register handlers
    app = tornado.web.Application([
            (r'/', AuthorSearchHandler, {'db': db}),
            (r'/author/(\d+)', AuthorDetailHandler, {'db': db}),
            (r'/css/(.*)', tornado.web.StaticFileHandler, {'path':'css'}),
        ],
        template_path = 'templates',
        debug = True
    )

    # run the app
    app.listen(8888)
    tornado.ioloop.IOLoop.current().start()
    
