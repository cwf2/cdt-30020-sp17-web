#!/usr/bin/env python
'''Interact with a catalogue of children's fiction'''

# import statements
import sqlite3
import json

# class definitions
class LibraryDB(object):
    '''A connection to the library database'''
    
    def __init__(self, db_file, auth_file, book_file):
        '''Initialize a new conenction to the database'''
        
        # save initialization variables
        self.db_file = db_file
        self.auth_file = auth_file
        self.book_file = book_file
        
        # open connection to database
        self.conn = sqlite3.connect(db_file)
        
        # allow column access by name
        self.conn.row_factory = sqlite3.Row
        
        # enforce foreign key constraints
        self.conn.execute('PRAGMA foreign_keys = ON')
        
        # initialize the tables
        self._build_tables()
        self._populate_tables()
        
    
    def _build_tables(self, clobber=True):
        '''Initialize the database tables'''
        
        # new cursor
        cur = self.conn.cursor()
        
        # delete existing tables?
        if clobber:
            cur.execute('''
            DROP TABLE IF EXISTS Book
            ''')
            cur.execute('''
            DROP TABLE IF EXISTS Author
            ''')

        
        # create table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS Author (
                auth_id     INTEGER PRIMARY KEY,
                last_name   TEXT,
                first_name  TEXT,
                birth       INTEGER,
                death       INTEGER,
                nationality TEXT,
                bio         TEXT,
                image_url   TEXT
            )
        ''')

        cur.execute('''
            CREATE TABLE IF NOT EXISTS Book (
                book_id     INTEGER PRIMARY KEY,
                title       TEXT,
                auth_id     INTEGER,
                pub         INTEGER,
                FOREIGN KEY (auth_id) REFERENCES Author(auth_id)
            )
        ''')


    def _populate_tables(self):
        '''Fill the tables using TSV data'''
        
        # new cursor
        cur = self.conn.cursor()
        
        # populate Author
        with open(self.auth_file) as fh:
            data = json.load(fh)
            
            insert_sql = '''
                INSERT INTO Author VALUES (
                   :author_id,
                   :last_name,
                   :first_name,
                   :birth,
                   :death,
                   :nationality,
                   :bio,
                   :image
                )'''
            
            cur.executemany(insert_sql, data)
        
        # populate Book
        with open(self.book_file) as fh:
            data = json.load(fh)
            
            insert_sql = '''
            INSERT INTO Book VALUES (
                :book_id,
                :title,
                :author_id,
                :published
            )'''
            
            for rec in data:
                try:
                    cur.execute(insert_sql, rec)
                except sqlite3.IntegrityError:
                    print "Couldn't add record:", rec
        
        self.conn.commit()


    def search_books_title(self, title):
        '''Look for Books with title like query
        
        Returns: book_id, first_name, last_name, title, pub.'''
        
        # new cursor
        cur = self.conn.cursor()
        
        # sql statement
        sql = '''
        SELECT 
            Book.book_id,
            Author.first_name,
            Author.last_name,
            Book.title, 
            Book.pub
        FROM 
            Book JOIN Author 
        USING 
            (auth_id)
        WHERE
            Book.title LIKE ?
        '''
        
        cur.execute(sql, (title,))
        return cur.fetchall()


    def search_books_author(self, auth_id):
        '''Get all books by a given author
        
        Returns title, pub.'''
        
        # new cursor
        cur = self.conn.cursor()
        
        # sql statement
        sql = 'SELECT title, pub FROM Book WHERE auth_id == ?'
        
        cur.execute(sql, (auth_id,))        
        return cur.fetchall()


    def search_authors_name(self, name=""):
        '''Look for authors with name like query
        
        Returns: auth_id, first_name, last_name, birth, death
        '''
        
        # new cursor
        cur = self.conn.cursor()
        
        # sql statement
        sql = '''
        SELECT
            auth_id,
            first_name,
            last_name,
            birth,
            death
        FROM 
            Author 
        WHERE 
            first_name || " " || last_name 
        LIKE ?
        ORDER BY 
            last_name,
            first_name,
            birth
        
        '''
        
        cur.execute(sql, (name,))
        return cur.fetchall()


    def author_detail(self, auth_id):
        '''Get complete record for an author
        
        Returns: auth_id, first_name, last_name, birth, death, nationality,
        bio, image_url.
        '''
        
        # new cursor
        cur = self.conn.cursor()
        
        # sql statement
        sql = '''
        SELECT
            auth_id, 
            first_name,
            last_name,
            birth,
            death,
            nationality,
            bio,
            image_url
        FROM 
            Author 
        WHERE 
            auth_id == ?
        '''
        
        cur.execute(sql, (auth_id,))
        return cur.fetchone()

